# Urban WiFi synthetic processing tutorial

This self-contained archive exercises the maintained SQLite-to-one-second-to-
20-second processing chain and all five metric calculations. Every observation,
identifier input, sensor coordinate, and timestamp scenario is synthetic. The
archive contains no field record, raw MAC address, deployment or release key,
identifier mapping, geographic coordinate, author identity, or Git history.

The SQLite fixture contains only the minimal `packets` table because no hardware
capture occurred. Its 32-character identifiers are deterministic HMAC outputs
from synthetic scenario-role labels, not observed addresses. The fixture
manifest deliberately prints one fixed public test-only key so the calculation
contract is reproducible. Never use that value for collection or deployment.

## Integrity

The outer `.sha256` file authenticates the downloaded ZIP. Inside the ZIP,
`MANIFEST.sha256` covers every other member. The archive builder verifies the
exact member allowlist, hashes, fixed ZIP metadata, fixture provenance fields,
and privacy scan before extraction.

From a repository checkout, verify and safely extract with:

```text
python scripts/pipeline/build_synthetic_tutorial_archive.py verify --archive docs/downloads/urban-wifi-synthetic-pipeline.zip --checksum docs/downloads/urban-wifi-synthetic-pipeline.sha256 --extract-dir synthetic-tutorial
```

## Offline checks after extraction

Run the eight fixture tests:

```text
python -m unittest discover -s tests/ch3_maintained_fixture -p test_*.py
```

Verify the committed processing outputs and five-metric outputs:

```text
Rscript scripts/pipeline/04_verify_pipeline.R --one-second workflow/ch3_tutorial/maintained_pipeline/01_aggregated_1second.parquet --cleaned-one-second workflow/ch3_tutorial/maintained_pipeline/02_cleaned_1second.parquet --twenty-second workflow/ch3_tutorial/maintained_pipeline/03_analysis_20second.parquet

Rscript scripts/pipeline/06_verify_five_metrics.R --input workflow/ch3_tutorial/maintained_pipeline/03_analysis_20second.parquet --sensors workflow/ch3_tutorial/maintained_capture_fixture/synthetic_sensors.csv --fixture-manifest workflow/ch3_tutorial/maintained_capture_fixture/manifest.json --output-dir workflow/ch3_tutorial/maintained_metrics
```

The Python generator and the two R entry points can rebuild the fixture and
outputs in separate temporary directories. See `scripts/pipeline/README.md` for
the exact commands and declared thresholds. These artifacts test calculation
contracts only. They neither reproduce historical field results nor establish
sensor accuracy, pedestrian counts, anonymity, or permission to release data.
