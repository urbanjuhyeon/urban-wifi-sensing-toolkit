"""Hardware-independent regression tests."""
